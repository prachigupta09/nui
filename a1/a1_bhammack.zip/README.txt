Benjamin Hammack
bhammack
python pdollar.py 		(written for Python 2.7)
Linux