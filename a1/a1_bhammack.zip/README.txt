Benjamin Hammack
bhammack
python pdollar.py
Linux (Script written for python 2.7)